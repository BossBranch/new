# Better Inventory

Better Inventory is an inventory improvement mod for Minecraft Bedrock edition, version `1.21.0.3`. The mod is built with [Amethyst](https://github.com/FrederoxDev/Amethyst) and it adds in a shulker box preview, as well as the ability to see extra information about other items, like its identifier, namespace, durability and aux id.

### Shulker box previewer
![image](https://github.com/FrederoxDev/Better-Inventory/assets/69014593/a6f26fd7-f934-4a9a-95ba-5f03eb950509)

### Item Information
![image](https://github.com/FrederoxDev/Better-Inventory/assets/69014593/97290890-1a12-4c61-a9ac-407bf78289d6)
