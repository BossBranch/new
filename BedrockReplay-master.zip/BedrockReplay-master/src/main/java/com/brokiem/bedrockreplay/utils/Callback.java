package com.brokiem.bedrockreplay.utils;

public interface Callback {
    void onSuccess();
    void onFailure(String errorMessage);
}
