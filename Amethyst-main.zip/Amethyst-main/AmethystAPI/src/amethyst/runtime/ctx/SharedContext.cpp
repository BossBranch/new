#include "amethyst/runtime/ctx/SharedContext.hpp"

Amethyst::SharedContext::SharedContext()
    : mCreativeRegistry(), mMinecraft(nullptr) {}
