#pragma once
#include "mc/src-client/common/client/gui/screens/AbstractScene.hpp"

class BaseScreen : public AbstractScene {};