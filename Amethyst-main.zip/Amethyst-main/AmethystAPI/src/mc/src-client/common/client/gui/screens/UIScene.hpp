#pragma once
#include "mc/src-client/common/client/gui/screens/BaseScreen.hpp"

class UIScene : public BaseScreen {};