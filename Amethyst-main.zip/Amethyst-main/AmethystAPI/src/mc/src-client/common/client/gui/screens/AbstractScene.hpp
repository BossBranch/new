#pragma once

class AbstractScene {};